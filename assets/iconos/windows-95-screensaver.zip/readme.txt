﻿=== Windows 95 Screensaver Icon Set ===

By: User (http://www.rw-designer.com/user/115294) mgjcueto1@gmail.com

Download: http://www.rw-designer.com/icon-set/windows-95-screensaver

Author's description:

The screensavers inside a computer from windows 95 which was extracted into (c:)/Windows/System32.

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.