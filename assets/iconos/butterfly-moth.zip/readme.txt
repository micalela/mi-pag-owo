﻿=== Butterfly Icon Set ===

By: Vlasta (http://www.rw-designer.com/user/1)

Download: http://www.rw-designer.com/icon-set/butterfly-moth

Author's description:

A couple of butterflies widespread in most of Europe. And one moth.

==========

License: Creative Commons - Attribution

You are free:

* To Share - To copy, distribute and transmit the work.
* To Remix - To adapt the work.

Under the following conditions:

* Attribution - You must attribute the work in the manner specified
  by the author or licensor (but not in any way that suggests that
  they endorse you or your use of the work). For example, if you are
  making the work available on the Internet, you must link to the
  original source.